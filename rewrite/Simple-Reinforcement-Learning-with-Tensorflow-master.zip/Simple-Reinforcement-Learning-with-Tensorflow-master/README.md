# Simple-Reinforcement-Learning-with-Tensorflow

Re-write of code from [Simple Reinforcement Learning with Tensorflow](https://medium.com/emergent-future/simple-reinforcement-learning-with-tensorflow-part-0-q-learning-with-tables-and-neural-networks-d195264329d0#.dxzgzsnfo)